This folder comprises a Hail (www.hail.is) native Table or MatrixTable.
  Written with version 0.2.132-678e1f52b999
  Created at 2024/10/23 12:18:22